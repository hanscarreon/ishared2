$(document).ready(function(){
		
		// alert();

		setTImeout(function(){
	 $('#orderTable').DataTable();
	},10000)
})