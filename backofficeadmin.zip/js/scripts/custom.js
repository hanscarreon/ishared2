$(document).ready(function(){
	
	// $('.phone-num').mask('00-0000-00000');
	

});

